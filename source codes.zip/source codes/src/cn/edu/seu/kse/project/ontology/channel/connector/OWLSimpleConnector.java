package cn.edu.seu.kse.project.ontology.channel.connector;

import java.util.Set;

import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;

import cn.edu.seu.kse.project.ontology.channel.formater.SimpleOntologyFormattingVisitor;
import cn.edu.seu.kse.project.ontology.channel.translator.OWLAxiomTranslationVisitor;
import cn.edu.seu.kse.project.ontology.owl.OWLOntologyBase;
import cn.edu.seu.kse.project.ontology.simple.api.SimpleOntologyBase;
import cn.edu.seu.kse.project.ontology.simple.structure.SimpleAxiom;
import cn.edu.seu.kse.project.ontology.simple.structure.SimpleAxiomFactory;
import cn.edu.seu.kse.project.toolkit.ProcessReporter;
import cn.edu.seu.kse.project.toolkit.logger.Logger;

/**
 * 
 * This class is used to do translation between owl ontologies
 * and simple ontologies defined in this system.
 * 
 * @author Zhangquan Zhou
 * 
 * @time 2017-4-14
 *
 */
public class OWLSimpleConnector {
	
	// the class designed for owl ontology management.
	private OWLOntologyBase owlOntoBase;
	
	private OWLDataFactory dataFactory;
	
	// the class designed for simple ontology management.
	private SimpleOntologyBase simpleOntoBase;
	
	// supporting creating indexes for simple ontologies.
	private OWLSimpleAllocater allocater = null;
	
	private SimpleOWLAllocater revAllocater = null;
	
	// saving indexes.
	protected OWLSimpleIndex index = null;
	
	private SimpleAxiomFactory simpleAxiomFactory;
	
	// used for translation
	private OWLAxiomTranslationVisitor axiomTranslationVisitor;
	
	private SimpleOntologyFormattingVisitor formattingVisitor;

	private Logger log;
	
	
	public OWLSimpleConnector(
			OWLOntologyBase owlBase, 
			SimpleOntologyBase simpleBase,
			Logger log) {
		
		this.owlOntoBase = owlBase;	
		this.dataFactory = this.owlOntoBase.getDataFactory();
		
		this.simpleOntoBase = simpleBase;	
		this.index = new OWLSimpleIndex(this);	
		this.simpleAxiomFactory = index.simpleAxiomFactory;
		
		this.allocater = new OWLSimpleAllocater(index);	
		this.revAllocater = new SimpleOWLAllocater(index);
		
		this.log = log;
		
		this.axiomTranslationVisitor = 
				new OWLAxiomTranslationVisitor(this);
		this.formattingVisitor = 
				new SimpleOntologyFormattingVisitor(this);
		
	}
	
	public void register(SimpleAxiom simpleAxiom){	
		
		this.index.simpleAxiomSet.add(simpleAxiom);			
		this.simpleOntoBase.registerSimpleAxiom(simpleAxiom);		
	}
	
	public OWLSimpleAllocater getAllocater() {
		return allocater;
	}
	
	public SimpleOWLAllocater getReverseAllocater(){
		return revAllocater;
	}
	
	public OWLDataFactory getOWLDataFactory() {
		return dataFactory;
	}
	
	public SimpleAxiomFactory getSimpleAxiomFactory(){
		return simpleAxiomFactory;
	}
	
	public void translate(){

		// the target owl ontology.
		OWLOntology ontology = owlOntoBase.getOntology();

		// translate axioms to normal forms.
		Set<OWLAxiom> owlAxioms = ontology.getAxioms();
		ProcessReporter report = new ProcessReporter(owlAxioms.size(), log);
		for (OWLAxiom owlAxiom : owlAxioms) {
			owlAxiom.accept(axiomTranslationVisitor);
			report.anotherProcessed();
		}
		
		// register inverse roles.
		Set<Integer> roles = index.inversePropertyIntegerMap.keySet();
		for(Integer role : roles) {
			Integer inverseRole = 
					index.inversePropertyIntegerMap.get(role);
			simpleOntoBase.registerInverseProperties(role, inverseRole);
		}
	}
	
	public void format(OWLOntologyBase newOWLBase) {
		formattingVisitor.setTargetOWLOntologyBase(newOWLBase);
		
		if(simpleOntoBase!=null) {
			Set<SimpleAxiom> simpleAxioms = 
					simpleOntoBase.getABoxAxioms();
	
			for(SimpleAxiom axiom : simpleAxioms) {
				axiom.accept(formattingVisitor);
			}		
		}	
	}
	
}
