package cn.edu.seu.kse.project.materializer.examples;

import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyStatisticer;
import cn.edu.seu.kse.project.ontology.channel.connector.OWLSimpleConnector;
import cn.edu.seu.kse.project.ontology.channel.connector.SimpleOntologyStatisticer;
import cn.edu.seu.kse.project.ontology.owl.OWLOntologyBase;
import cn.edu.seu.kse.project.ontology.owl.statistic.OWLOntologyStatisticer;
import cn.edu.seu.kse.project.reasoner.api.SimpleReasoner;
import cn.edu.seu.kse.project.reasoner.api.SimpleReasonerManager;
import cn.edu.seu.kse.project.toolkit.Tool;
import cn.edu.seu.kse.project.toolkit.logger.Logger;
import cn.edu.seu.kse.project.toolkit.logger.SystemPort;

public class TestDHLMaterialization {
	
	public static void main(String[] args) {
		
		int numOfCopy = 0;
		int numOfJoint = 100000;
		
		String dir = "C:\\Users\\Spring\\Desktop\\Work\\0_PT_J\\"
				+ "system\\ontologies\\";
		
		String fileName = "leftexistential";	
		String inputFilePath = dir + "generating\\" + fileName+"-All-generate-"+numOfCopy
				+"-"+numOfJoint+".owl";
		
		String outFilePath = dir + fileName+"-result.owl";
		
		int numOfThreads = 2;
		long startTime = 0;
		long endTime = 0;
		
		Logger log = new SystemPort(Logger.DEBUG);
		
		// create an OWL ontology for a given path.
		OWLOntologyBase originalOntoBase = new OWLOntologyBase(log);
		Tool.pl("loading...");
		originalOntoBase.loadLocalOntologyFile(inputFilePath);
		Tool.pl("loading done.");

		// print the statistics of the given owl ontology.
		OWLOntologyStatisticer owlOntologyStatisticer =
				new OWLOntologyStatisticer(originalOntoBase.getOntology());
		owlOntologyStatisticer.printReport();
		
		//originalOntoBase.printAxioms(originalOntoBase.getOntology());
		
		// a test unit
		DHLOntologyBase simpleOntoBase = new DHLOntologyBase(log);
		
		// this is a connector between owl and smple ontologies.
		OWLSimpleConnector owlSimpleConnector = new OWLSimpleConnector(
				originalOntoBase, simpleOntoBase,log);
				
		// do translation.
		Tool.pl("translating...");
		owlSimpleConnector.translate();
		Tool.pl("translation done.");
				
		SimpleOntologyStatisticer simpleOntologyStatisticer = 
				new SimpleOntologyStatisticer(owlSimpleConnector);
		simpleOntologyStatisticer.printReport();	
		
		DHLOntologyStatisticer dhlOntologyStatisticer = 
				new DHLOntologyStatisticer(simpleOntoBase);
		dhlOntologyStatisticer.printReport();
		
		//simpleOntoBase.printAxioms();
		
		// do materialization.
		
		SimpleReasoner reasoner = 
				SimpleReasonerManager.createParallelDHLReasoner(simpleOntoBase,
						SimpleReasoner.MATERIALIZER,numOfThreads,log);
		
		Tool.pl("reasoning...");
		if(reasoner != null) {
			startTime = System.currentTimeMillis();
			reasoner.saturate();
			endTime = System.currentTimeMillis();
		}
		Tool.pl("reasoning done, reasoning time: " + (endTime - startTime) + " ms.");
		
		
		
		/*
		dhlOntologyStatisticer.printReport();
		
		Tool.pl("writting...");
		OWLOntologyBase newOwlBase = new OWLOntologyBase(log);
		newOwlBase.createNewOntology();
		SimpleOntologyFormatter.formate(
				owlSimpleConnector, newOwlBase, simpleOntoBase);
		
		//newOwlBase.printAxioms(newOwlBase.getOntology());
		
		newOwlBase.write(outFilePath);
		Tool.pl("writting done.");
		*/
		
		
	}

}
