package cn.edu.seu.kse.project.toolkit.parallel;

public interface ParallelTask {
	
	

}
