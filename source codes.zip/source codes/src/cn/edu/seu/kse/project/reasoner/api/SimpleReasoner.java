package cn.edu.seu.kse.project.reasoner.api;

public interface SimpleReasoner {
	
	public static int MATERIALIZER = 0;
	
	public void saturate();

}
