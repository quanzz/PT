package cn.edu.seu.kse.project.ontology.simple.structure;



public class SimpleOntologyFactory {
	
	public static SimpleAxiomFactory getSimpleAxiomFactory(){
		return new SimpleAxiomFactory();
	}

}
