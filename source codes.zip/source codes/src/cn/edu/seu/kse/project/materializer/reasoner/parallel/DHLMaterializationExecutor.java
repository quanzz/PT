package cn.edu.seu.kse.project.materializer.reasoner.parallel;

import java.util.ArrayList;
import java.util.List;

import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.reasoner.DHLMaterializer;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLInversePropertyRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLLeftExistentialRuleForClassAssertion;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLLeftExistentialRuleForRoleAssertion;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLObjectIntersectionOfRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLPropertyChianOfRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLSubClassOfRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLSubObjectPropertyOfRule;
import cn.edu.seu.kse.project.materializer.reasoner.rules.DHLTransitivePropertyRule;
import cn.edu.seu.kse.project.ontology.exception.OntoException;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelExecutor;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelMaster;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelTask;

public class DHLMaterializationExecutor implements ParallelExecutor {
	
	private DHLMaterializer materializer;
	private DHLOntologyBase ontoBase;
	
	private DHLMaterializationTask task;
	private ParallelMaster parallelMaster;
	
	private List<DHLRule> DHLRuleSet;
	
	public DHLMaterializationExecutor(
			DHLMaterializer materializer,
			DHLOntologyBase ontoBase) {
		
		this.materializer = materializer;
		this.ontoBase = ontoBase;
		
		this.parallelMaster = 
				materializer.getParallelMaster();
		
		this.DHLRuleSet = new ArrayList<DHLRule>();
		
		DHLRuleSet.add(new DHLSubClassOfRule());
		DHLRuleSet.add(new DHLObjectIntersectionOfRule());
		DHLRuleSet.add(new DHLLeftExistentialRuleForClassAssertion());
		
		DHLRuleSet.add(new DHLInversePropertyRule());
		DHLRuleSet.add(new DHLSubObjectPropertyOfRule());
		DHLRuleSet.add(new DHLTransitivePropertyRule());
		DHLRuleSet.add(new DHLPropertyChianOfRule());
		DHLRuleSet.add(new DHLLeftExistentialRuleForRoleAssertion());		
		
		//DHLRuleSet.add(new DHLSWDRule());
		//DHLRuleSet.add(new DHLTransferRule());	
	}
	

	@Override
	public void setNewParallelTask(ParallelTask task) {
		if(task instanceof DHLMaterializationTask) {
			this.task = (DHLMaterializationTask) task;
		} else {
			try {
				throw new OntoException("The new task is not "
						+ "a materialization task.");
			} catch (OntoException e) {
				e.printStackTrace();
			}
		}	
	}


	@Override
	public void setVacant() {
		parallelMaster.setVacant(this);
	}

	@Override
	public void run() {
		
		DHLAxiom processedAxiom = task.getTargetAxiom();
		
		for(DHLRule rule : DHLRuleSet) {
			rule.apply(processedAxiom, materializer, ontoBase);
		}

		setVacant();
	}
	
}
