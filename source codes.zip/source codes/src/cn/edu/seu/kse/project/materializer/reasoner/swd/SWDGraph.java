package cn.edu.seu.kse.project.materializer.reasoner.swd;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.ontology.util.AdditionUtil;

public class SWDGraph {
	
	
	private Map<Integer,Map<Integer,Map<Integer,Map<Integer,Set<DHLAxiom>>>>> edges;
	
	private Map<Integer, Map<Integer, Set<DHLAxiom>>> parentToChildrenMap;
	private Map<Integer, Map<Integer, Set<DHLAxiom>>> childToParentsMap;
	
	public SWDGraph(){
		this.edges = new ConcurrentHashMap<Integer,Map<Integer,Map<Integer,Map<Integer,Set<DHLAxiom>>>>>();
		this.parentToChildrenMap = new ConcurrentHashMap<Integer, Map<Integer,Set<DHLAxiom>>>();
		this.childToParentsMap = new ConcurrentHashMap<Integer, Map<Integer,Set<DHLAxiom>>>();
	}
	
	public void addEdge(DHLSWDRelation relation) {
		AdditionUtil.addElement(
				relation.getClass1(), relation.getMember1(), 
				relation.getClass2(), relation.getMember2(), relation, edges);
		AdditionUtil.addElement(relation.getClass1(), relation.getMember1(), 
				relation, parentToChildrenMap);
		AdditionUtil.addElement(relation.getClass2(), relation.getMember2(), 
				relation, childToParentsMap);
	}
	
	public Set<DHLAxiom> getEdgesByParent(Integer class1, Integer member1) {
		Set<DHLAxiom> result = null;
		
		if(parentToChildrenMap.containsKey(class1)) {
			Map<Integer,Set<DHLAxiom>> subMap = parentToChildrenMap.get(class1);
			if(subMap.containsKey(member1)) {
				result = subMap.get(member1);
			}
		}
		return result;
	}
	
	public Set<DHLAxiom> getEdgesByChild(Integer class2, Integer member2) {
		Set<DHLAxiom> result = null;
		
		if(childToParentsMap.containsKey(class2)) {
			Map<Integer,Set<DHLAxiom>> subMap = childToParentsMap.get(class2);
			if(subMap.containsKey(member2)) {
				result = subMap.get(member2);
			}
		}
		return result;
	}
	
	public boolean containsEdge(
			Integer class1, Integer member1,
			Integer class2, Integer member2){
		if(edges.containsKey(class1)) {
			Map<Integer,Map<Integer,Map<Integer,Set<DHLAxiom>>>> subMap =
					edges.get(class1);
			
			if(subMap.containsKey(member1)) {
				Map<Integer,Map<Integer,Set<DHLAxiom>>> subsubMap = subMap.get(member1);
				
				if(subsubMap.containsKey(class2)) {
					Map<Integer,Set<DHLAxiom>> subsubsubMap = subsubMap.get(class2);
					
					if(subsubsubMap.containsKey(member2)) {
						return true;
					}
				}
			}
		}
		return false;
	}


}
