package cn.edu.seu.kse.project.materializer.reasoner.rules;

import java.util.Set;

import cn.edu.seu.kse.project.materializer.ontology.DHLBaseAccessor;
import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLClassAssertion;
import cn.edu.seu.kse.project.materializer.reasoner.DHLMaterializer;
import cn.edu.seu.kse.project.materializer.reasoner.parallel.DHLMaterializationController;
import cn.edu.seu.kse.project.materializer.reasoner.swd.DHLSWDRelation;

public class DHLSWDRule implements DHLRule {

	@Override
	public void apply(
			DHLAxiom trigger, 
			DHLMaterializer materializer,
			DHLOntologyBase ontoBase) {
		
		if(!(trigger instanceof DHLClassAssertion)) return;		
		
		DHLBaseAccessor accessor = ontoBase.getBaseAccessor();
		DHLMaterializationController controller = materializer.getMaterializationController();
		
		DHLClassAssertion classAssertion = (DHLClassAssertion) trigger;	
		Integer concept = classAssertion.getConcept();
		Integer member = classAssertion.getMember();
		
		Set<DHLAxiom> derivations = controller.getDerivations(concept, member);
		
		if(derivations != null) {
			for(DHLAxiom axiom : derivations) {
				DHLSWDRelation relation = (DHLSWDRelation) axiom;
				
				Integer class2 = relation.getClass2();
				Integer member2 = relation.getMember2();
				
				if(!accessor.containsClassAssertion(class2, member2)){
					controller.deriveClassAssertion(class2, member2);
					
					
				}
			}
		}
		
	}

}
