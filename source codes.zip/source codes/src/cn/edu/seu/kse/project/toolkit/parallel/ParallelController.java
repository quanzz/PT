package cn.edu.seu.kse.project.toolkit.parallel;

public interface ParallelController {
	
	public boolean hasParallelTask();
	
	public ParallelTask getNewParallelTask();

}
