package cn.edu.seu.kse.project.materializer.reasoner.swd;

import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiomVisitor;
import cn.edu.seu.kse.project.ontology.simple.structure.SimpleAxiomVisitor;

public class DHLSWDRelation implements DHLAxiom {
	
	private Integer class1 = 0;
	private Integer member1 = 0;
	
	private Integer class2 = 0;
	private Integer member2 = 0;
	
	
	

	public DHLSWDRelation(
			Integer class1, Integer member1, 
			Integer class2, Integer member2) {
		this.class1 = class1;
		this.member1 = member1;
		this.class2 = class2;
		this.member2 = member2;
	}

	public Integer getClass1() {
		return class1;
	}

	public Integer getMember1() {
		return member1;
	}

	public Integer getClass2() {
		return class2;
	}

	public Integer getMember2() {
		return member2;
	}



	@Override
	public void accept(SimpleAxiomVisitor axiomVisitor) {
		
	}

	@Override
	public void accept(DHLAxiomVisitor axiomVisitor) {
		
	}

}
