package cn.edu.seu.kse.project.ontology.simple.api;

import java.util.Set;

import cn.edu.seu.kse.project.ontology.simple.structure.SimpleAxiom;

/**
 * 
 * This is the interface for all classes
 * extending SimpleOntologyBase
 * 
 * 
 * @author Zhangquan Zhou
 *
 */
public interface SimpleOntologyBase {
	
	public Set<SimpleAxiom> getABoxAxioms();
	
	public Set<SimpleAxiom> getTBoxAxioms();
	
	public Set<SimpleAxiom> getAllAxioms();
	
	public void registerSimpleAxiom(SimpleAxiom axiom);
	
	public void registerInverseProperties(Integer role, Integer inverseRole);

}
