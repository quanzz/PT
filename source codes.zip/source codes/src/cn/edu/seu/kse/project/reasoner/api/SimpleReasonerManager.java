package cn.edu.seu.kse.project.reasoner.api;

import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.reasoner.DHLMaterializer;
import cn.edu.seu.kse.project.toolkit.logger.Logger;

public class SimpleReasonerManager {
	
	
	public static SimpleReasoner createDHLReasoner(
			DHLOntologyBase ontoBase, int reasonerType,Logger log){
		if(reasonerType == SimpleReasoner.MATERIALIZER) {
			return new DHLMaterializer(ontoBase,log);
		}
		return null;
	}
	
	public static SimpleReasoner createParallelDHLReasoner(
			DHLOntologyBase ontoBase, int reasonerType, int numOfThreads,Logger log){
		if(reasonerType == SimpleReasoner.MATERIALIZER) {
			DHLMaterializer materializer = new DHLMaterializer(ontoBase,log);
			materializer.setNumOfThreads(numOfThreads);
			return materializer;
		}
		return null;
	}

}
