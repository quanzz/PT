package cn.edu.seu.kse.project.materializer.reasoner.rules;

import cn.edu.seu.kse.project.materializer.ontology.DHLBaseAccessor;
import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.reasoner.DHLMaterializer;
import cn.edu.seu.kse.project.materializer.reasoner.parallel.DHLMaterializationController;
import cn.edu.seu.kse.project.materializer.reasoner.swd.DHLSWDRelation;

public class DHLTransferRule implements DHLRule {
	
	@Override
	public void apply(
			DHLAxiom trigger, 
			DHLMaterializer materializer,
			DHLOntologyBase ontoBase) {

		if(!(trigger instanceof DHLSWDRelation)) return;		
		
		DHLBaseAccessor accessor = ontoBase.getBaseAccessor();
		DHLMaterializationController controller = materializer.getMaterializationController();
		
		DHLSWDRelation swdRelation = (DHLSWDRelation) trigger;	
		Integer class1 = swdRelation.getClass1();
		Integer member1 = swdRelation.getMember1();
		Integer class2 = swdRelation.getClass2();
		Integer member2 = swdRelation.getMember2();
		
		if(accessor.containsClassAssertion(class1, member1)) {
			if(!accessor.containsClassAssertion(class2, member2)){
				controller.deriveClassAssertion(class2, member2);
			}
		} else {
			if(!accessor.containsClassAssertion(class2, member2)){
				controller.transfer(class1, member1, class2, member2);
			}
		}
		
		
		
	}

}
