package cn.edu.seu.kse.project.materializer.reasoner.rules;

import java.util.Map;
import java.util.Set;

import cn.edu.seu.kse.project.materializer.ontology.DHLBaseAccessor;
import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLClassAssertion;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLLeftExistentialAxiom;
import cn.edu.seu.kse.project.materializer.reasoner.DHLMaterializer;
import cn.edu.seu.kse.project.materializer.reasoner.parallel.DHLMaterializationController;

public class DHLLeftExistentialRuleForClassAssertion implements DHLRule {

	@Override
	public void apply(
			DHLAxiom trigger, 
			DHLMaterializer materializer,
			DHLOntologyBase ontoBase) {
		
		if(!(trigger instanceof DHLClassAssertion)) return;
		
		DHLBaseAccessor accessor = ontoBase.getBaseAccessor();
		DHLMaterializationController deriver = materializer.getMaterializationController();
		
		DHLClassAssertion classAssertion = 
				(DHLClassAssertion) trigger;
		
		Integer concept = classAssertion.getConcept();
		Integer member = classAssertion.getMember();
		
		Set<DHLAxiom> axioms = accessor.getLeftExistentialAxiomsBySubClass(concept);
		
		if(axioms != null) {
			for(DHLAxiom axiom : axioms) {
				DHLLeftExistentialAxiom leftExistentialAxiom = 
						(DHLLeftExistentialAxiom) axiom;
				
				Integer subRole = leftExistentialAxiom.getRole();
				Integer superClass = leftExistentialAxiom.getSuperConcept();
				
				Map<Integer, Set<DHLAxiom>> roleAssertions = 
						accessor.getObjectPropertyAssertionsByRoleAndObject(subRole, member);
				
				if(roleAssertions != null) {
					Set<Integer> subjects = roleAssertions.keySet();
					
					for(Integer subject : subjects) {
						if(!accessor.containsClassAssertion(superClass, subject)){
							deriver.deriveClassAssertion(superClass, subject);
						}
					}
				}
			}
		}
		
	}

}
