package cn.edu.seu.kse.project.toolkit;

public class Tool {
	
	
	/**
	 * system printer.
	 * @param o an object
	 */
	public static void pl(Object o) {
		System.out.println(o);
	}
	
	public static void p(Object o) {
		System.out.print(o);
	}

}
