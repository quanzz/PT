package cn.edu.seu.kse.project.ontology.exception;

public class OntoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public OntoException(Object msg) {
		System.out.println(msg);
	}

}
