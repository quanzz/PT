package cn.edu.seu.kse.project.materializer.ontology.structure;

import java.util.Set;

import cn.edu.seu.kse.project.toolkit.Tool;

/**
 * 
 * This class is used for printing DHLAxioms.
 * 
 * @author Zhangquan Zhou
 *
 */
public class DHLAxiomPrinter implements DHLAxiomVisitor{

	
	public void print(Set<DHLAxiom> axioms){
		for(DHLAxiom axiom : axioms){
			axiom.accept(this);
		}
	}
	
	@Override
	public void visit(DHLLeftExistentialAxiom arg) {
		Tool.pl("LeftExistentialAxiom(("+arg.getRole()+","+arg.getSubConcept()+"),"+arg.getSuperConcept()+")");
	}

	@Override
	public void visit(DHLObjectIntersectionOfAxiom arg) {
		Tool.pl("IntersectionOfAxiom(("+arg.getSubFirstConcept()+","+arg.getSubSecondConcept()+"),"+arg.getSuperConcept()+")");
	}

	@Override
	public void visit(DHLSubClassOfAxiom arg) {
		Tool.pl("SubClassOfAxiom("+arg.getSubConcept()+","+arg.getSuperConcept()+")");
	}

	@Override
	public void visit(DHLSubObjectPropertyOfAxiom arg) {
		Tool.pl("SubObjectPropertyOfAxiom("+arg.getSubProperty()+","+arg.getSuperProperty()+")");
	}

	@Override
	public void visit(DHLSubPropertyChainOfAxiom arg) {
		Tool.pl("SubPropertyChainOfAxiom(("+arg.getSubProperty1()+","+arg.getSubProperty2()+"),"+arg.getSuperProperty()+")");
	}

	@Override
	public void visit(DHLTransitiveObjectPropertyAxiom arg) {
		Tool.pl("TransitiveObjectPropertyAxiom("+arg.getProperty()+")");
	}

	@Override
	public void visit(DHLClassAssertion arg) {
		Tool.pl("ClassAssertion("+arg.getConcept()+","+arg.getMember()+")");
	}

	@Override
	public void visit(DHLObjectPropertyAssertion arg) {
		Tool.pl("ObjectPropertyAssertion("+arg.getProperty()+","+arg.getSubject()+","+arg.getObject()+")");
	}

}
