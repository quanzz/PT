package cn.edu.seu.kse.project.ontology.simple.structure;

public interface SimpleAxiom {

	public void accept(SimpleAxiomVisitor axiomVisitor);
	
}
