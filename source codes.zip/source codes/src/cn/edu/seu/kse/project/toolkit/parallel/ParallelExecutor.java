package cn.edu.seu.kse.project.toolkit.parallel;

public interface ParallelExecutor extends Runnable {
	
	public void setNewParallelTask(ParallelTask task);
	
	public void setVacant();

}
