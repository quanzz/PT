package cn.edu.seu.kse.project.materializer.reasoner.parallel;

import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelTask;

public class DHLMaterializationTask implements ParallelTask {
	
	private DHLAxiom processedAxiom;
	
	DHLMaterializationTask(DHLAxiom processedAxiom) {
		this.processedAxiom = processedAxiom;
	}
	
	public DHLAxiom getTargetAxiom(){
		return processedAxiom;
	}

}
