package cn.edu.seu.kse.project.materializer.reasoner.parallel;

import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

import cn.edu.seu.kse.project.materializer.ontology.DHLBaseAccessor;
import cn.edu.seu.kse.project.materializer.ontology.DHLBaseAdditor;
import cn.edu.seu.kse.project.materializer.ontology.DHLOntologyBase;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiom;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLAxiomFactory;
import cn.edu.seu.kse.project.materializer.ontology.structure.DHLClassAssertion;
import cn.edu.seu.kse.project.materializer.reasoner.swd.DHLSWDRelation;
import cn.edu.seu.kse.project.materializer.reasoner.swd.SWDGraph;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelController;
import cn.edu.seu.kse.project.toolkit.parallel.ParallelTask;

public class DHLMaterializationController implements ParallelController {
	
	private DHLBaseAdditor additor;
	private DHLBaseAccessor accessor;
	private DHLAxiomFactory factory;
	
	private ConcurrentLinkedQueue<DHLAxiom> workingQueue;
	private SWDGraph graph;
	
	public DHLMaterializationController(
			DHLOntologyBase ontologyBase){
		
		this.additor = ontologyBase.getBaseAdditor();
		this.accessor = ontologyBase.getBaseAccessor();
		this.factory = ontologyBase.getAxiomFactory();
		
		this.workingQueue = new ConcurrentLinkedQueue<DHLAxiom>();
		this.graph = new SWDGraph();
	}
	
	/**
	 * put all original assertions in the workingQueue.
	 */
	public void initialize(){
		Set<DHLAxiom> classAssertions = 
				accessor.getAllClassAssertions();
		if(classAssertions!=null) {
			for(DHLAxiom axiom : classAssertions) {
				workingQueue.offer(axiom);
			}
		}
		
		Set<DHLAxiom> roleAssertions = 
				accessor.getAllRoleAssertions();
		if(roleAssertions!=null) {
			for(DHLAxiom axiom : roleAssertions) {
				workingQueue.offer(axiom);
			}
		}
	}
	
	// functions for parallelism
	public void put(DHLAxiom axiom){
		workingQueue.offer(axiom);
	}
	
	@Override
	public ParallelTask getNewParallelTask(){
		DHLMaterializationTask task = null;
		
		DHLAxiom axiom = null;	
		if(!workingQueue.isEmpty()){
			axiom = workingQueue.poll();
		}
		
		if(axiom!= null) {
			task = new DHLMaterializationTask(axiom);
		}
		
		return task;	
	}

	@Override
	public boolean hasParallelTask() {
		if(workingQueue.isEmpty()) 
			return false;
		return true;
	}	
	
	
	// correlater
	
	public Set<DHLAxiom> getDerivations(Integer class1, Integer member1) {
		return graph.getEdgesByParent(class1, member1);
	}
	
	public void correlateClassAssertions(
			Integer class1, Integer member1,
			Integer class2, Integer member2){
		if(!graph.containsEdge(class1, member1, class2, member2)){
			DHLSWDRelation axiom = factory.getSWDRelation(class1, member1, class2, member2);
			graph.addEdge(axiom);
			this.put(axiom);
			
			
			
		}
	}
	
	public void transfer(
			Integer class1, Integer member1,
			Integer class2, Integer member2){
		
		Set<DHLAxiom> children = graph.getEdgesByParent(class2, member2);
		if(children!=null) {
			for(DHLAxiom axiom : children) {
				DHLSWDRelation relation = (DHLSWDRelation) axiom;
				Integer class3 = relation.getClass2();
				Integer member3 = relation.getMember2();
				
				correlateClassAssertions(class1, member1, class3, member3);
			}
		}
		
		Set<DHLAxiom> parents = graph.getEdgesByChild(class1, member1);
		if(parents!=null) {
			for(DHLAxiom axiom : parents) {
				DHLSWDRelation relation = (DHLSWDRelation) axiom;
				Integer class0 = relation.getClass1();
				Integer member0 = relation.getMember1();
				
				correlateClassAssertions(class0, member0, class2, member2);
			}
		}
		
	}

	
	// dreiver
	
	public void deriveClassAssertion(
			Integer concept, 
			Integer member) {
		
		DHLAxiom axiom = factory.getDHLClassAssertion(concept, member);
		additor.addAxiom(axiom);
		this.put(axiom);
	}
	
	public void deriveClassAssertion(
			DHLClassAssertion classAssertion) {
		
		additor.addAxiom(classAssertion);
		this.put(classAssertion);
	}
	
	public void deriveRoleAssertion(
			Integer role, 
			Integer subject, 
			Integer object) {
		DHLAxiom axiom = factory.getDHLObjectPropertyAssertion(role, subject, object);
		additor.addAxiom(axiom);
		this.put(axiom);
	}


}
